#include <time.h>
#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <sys/select.h>
#include <pthread.h>
#include <signal.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/shm.h>
#include <unistd.h>
#include <sys/un.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <errno.h>
#include <netinet/if_ether.h>
#include <net/ethernet.h>
#include <netinet/ether.h>
#include <netinet/udp.h>

#define PORT 8080
#define serverIP "127.0.0.1"

void send_message(const char *ip_address, const char *message) {
    int sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_RAW);
    if (sockfd == -1) {
        perror("Error creating raw socket");
        exit(EXIT_FAILURE);
    }

    struct sockaddr_in dest_addr;
    dest_addr.sin_family = AF_INET;
    dest_addr.sin_port = htons(0);  // Set to 0 for raw socket
    inet_pton(AF_INET, ip_address, &(dest_addr.sin_addr));
    int one = 1;
    const int *val = &one;
    if (setsockopt(sockfd, IPPROTO_IP, IP_HDRINCL, val, sizeof(one)) < 0) {
        perror("Error setting IP_HDRINCL option");
        exit(EXIT_FAILURE);
    }
    // Prepare the IP header
    struct iphdr ip_header;
    memset(&ip_header, 0, sizeof(ip_header));
    ip_header.ihl = 5;
    ip_header.version = 4;
    ip_header.tos = 0;
    ip_header.id = htons(54321);
    ip_header.frag_off = 0;
    ip_header.ttl = 255;
    ip_header.protocol = IPPROTO_UDP;
    ip_header.check = 0; // Don't calculate checksum for now
    ip_header.saddr = inet_addr("127.0.0.1"); // Source IP address
    ip_header.daddr = dest_addr.sin_addr.s_addr; // Destination IP address

    // Prepare the UDP header
    struct udphdr udp_header;
    memset(&udp_header, 0, sizeof(udp_header));
    udp_header.source = htons(12345); // Source port
    udp_header.dest = htons(8080);   // Destination port
    udp_header.len = htons(sizeof(struct udphdr) + strlen(message));
    udp_header.check = 0; // Don't calculate checksum for now

    // Allocate memory for the packet
    size_t packet_size = sizeof(struct iphdr) + sizeof(struct udphdr) + strlen(message);
    char *packet = (char *)malloc(packet_size);
    if (packet == NULL) {
        perror("Error allocating memory for packet");
        exit(EXIT_FAILURE);
    }
    // Copy the headers and message to the packet
    memcpy(packet, &ip_header, sizeof(struct iphdr));
    memcpy(packet + sizeof(struct iphdr), &udp_header, sizeof(struct udphdr));
    strcpy(packet + sizeof(struct iphdr) + sizeof(struct udphdr), message);

    // Send the packet
    if (sendto(sockfd, packet, packet_size, 0, (struct sockaddr *)&dest_addr, sizeof(dest_addr)) < 0) {
        perror("Error sending packet");
        exit(EXIT_FAILURE);
    }

    free(packet);
    close(sockfd);
}

int main() {
    int sfd;
    struct sockaddr_in serv_addr;

    if ((sfd = socket(AF_INET, SOCK_STREAM, 0)) == -1) {
        perror("\n socket ");
        return 1;
    } else {
        printf("\n socket created successfully");
    }

    bzero(&serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);
    serv_addr.sin_addr.s_addr = inet_addr(serverIP);

    if (connect(sfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) == -1) {
        perror("\n connect ");
        return 1;
    } 
    else {
        printf("\n connect successful ");
    }
    // Do something with the connected socket, for example, send/receive data
    printf("Now publisher will  publish through its fd\n");
    write(sfd,"my content is : ",sizeof("my content is :"));
    // Close the socket when done
    close(sfd);

    return 0;
}
