#include <time.h>
#include <stdio.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <sys/select.h>
#include <pthread.h>
#include <signal.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/shm.h>
#include <unistd.h>
#include <sys/un.h>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <errno.h>
#include <netinet/if_ether.h>
#include <net/ethernet.h>
#include <netinet/ether.h>
#include <netinet/udp.h>

#define PORT 8080
#define PORT1 1491
#define serverIP1 "127.0.0.1"
#define serverIP2 "127.0.0.2"
#define max_cli 1
#define max_sub 1

int dispatch_nsfd[max_cli]; // store publisher file descriptors
int sub_nsfd[max_sub];
char *pub1[max_sub];
int i1 = 0;
char *pub2[max_sub];
int i2 = 0;
char *pub3[max_sub];
int i3 = 0;
int main()
{
    int sfd;
    struct sockaddr_in serv_addr, cli_addr;
    socklen_t cli_len;

    if ((sfd = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {
        perror("\n socket ");
        return 1;
    }
    else
    {
        printf("\n socket created successfully");
    }
    bzero(&serv_addr, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);
    serv_addr.sin_addr.s_addr = inet_addr(serverIP1);
    int opt = 1;
    setsockopt(sfd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt));
    if (bind(sfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) == -1)
    {
        perror("\n bind : ");
        return 1;
    }
    else
    {
        printf("\n bind successful ");
    }

    listen(sfd, max_cli);

    // Accept connections and store publisher file descriptors in dispatch_nsfd array
    for (int i = 0; i < max_cli; ++i)
    {
        if ((dispatch_nsfd[i] = accept(sfd, (struct sockaddr *)&cli_addr, &cli_len)) == -1)
        {
            perror("\n accept ");
        }
        else
        {
            printf("\n  publisher no  %d  connected\n", i);
        }
    }
    printf("ALL publisher connected\n");
    // Now dispatch_nsfd array contains the publisher file descriptors

    // Close the file descriptors when done
    printf("now time to sub come to regsiter for pub\n");
    int sfd1;
    struct sockaddr_in serv_addr1, cli_addr1;
    socklen_t cli_len1;

    if ((sfd1 = socket(AF_INET, SOCK_STREAM, 0)) == -1)
    {
        perror("\n socket ");
        return 1;
    }
    else
    {
        printf("\n socket created successfully");
    }
    bzero(&serv_addr1, sizeof(serv_addr1));
    serv_addr1.sin_family = AF_INET;
    serv_addr1.sin_port = htons(PORT1);
    serv_addr1.sin_addr.s_addr = inet_addr(serverIP2);
    int opt1 = 1;
    setsockopt(sfd1, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt1, sizeof(opt1));

    if (bind(sfd1, (struct sockaddr *)&serv_addr1, sizeof(serv_addr1)) == -1)
    {
        perror("\n bind : ");
        return 1;
    }
    else
    {
        printf("\n bind successful ");
    }

    listen(sfd1, max_sub);

    // Accept connections and store publisher file descriptors in dispatch_nsfd array
    for (int i = 0; i < max_sub; ++i)
    {
        if ((sub_nsfd[i] = accept(sfd1, (struct sockaddr *)&cli_addr1, &cli_len1)) == -1)
        {
            perror("\n accept ");
        }
        else
        {
            printf("\n  subsciber no  %d  connected\n", i);
        }
    }
    printf("ALL subcriber connected \n");
    for (int i = 0; i < max_sub; i++)
    {
        printf("Subscriber %d and its choice", i);
        int receivedArray[5];
        int fd = sub_nsfd[i];
        ssize_t bytes_read = read(fd, receivedArray, sizeof(receivedArray));
        if (bytes_read == -1)
        {
            perror("Error reading from file descriptor");
            exit(EXIT_FAILURE);
        }
        else if (bytes_read == 0)
        {
            printf("End of file reached. Connection closed.\n");
        }
        else
        {
            printf("Successfully read %zd bytes from the file descriptor.\n", bytes_read);
        }

        char arrip[100];
        ssize_t ipread = read(fd, arrip, sizeof(arrip));
        printf("%s", arrip);
        printf("\n");
        for (size_t i = 0; i < 2; ++i)
        {
            printf("%d ", receivedArray[i]);
            if (receivedArray[i] == 1)
                pub1[i1++] = arrip;
            if (receivedArray[i] == 2)
                pub2[i2++] = arrip;
            if (receivedArray[i] == 3)
                pub3[i3++] = arrip;
        }
    }
    printf("Registration is completed for all subcriber \n");

    // for (int i = 0; i < max_cli; ++i)
    // {
    //     close(dispatch_nsfd[i]);
    // }
    printf("now publisher will publish the content\n");
    // through the
    printf("pub1 contents:\n");
    for (int i = 0; i < i1; i++)
    {
        printf("%s\n", pub1[i]);
    }

    // Print the contents of pub2
    printf("pub2 contents:\n");
    for (int i = 0; i < i2; i++)
    {
        printf("%s\n", pub2[i]);
    }
    // Print the contents of pub3
    printf("pub3 contents:\n");
    for (int i = 0; i < i3; i++)
    {
        printf("%s\n", pub3[i]);
    }
    
    
    close(sfd);

    return 0;
}
