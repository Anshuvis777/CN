#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <netinet/ip.h>
#include <sys/socket.h>
#include <unistd.h>
#include <arpa/inet.h>

int main() {
    int raw_socket = socket(AF_INET, SOCK_RAW, 100);

    if (raw_socket == -1) {
        perror("Socket creation error");
        exit(1);
    }

    struct sockaddr_in dest_addr;
    dest_addr.sin_family = AF_INET;
    dest_addr.sin_addr.s_addr = inet_addr("127.0.0.1");

    char packet[] = "Hello World";

    // Send the packet using sendto
    if (sendto(raw_socket, packet, sizeof(packet), 0, (struct sockaddr*)&dest_addr, sizeof(dest_addr)) == -1) {
        perror("Packet send error");
    } 
    else {
        printf("Packet sent successfully.\n");
    }
    close(raw_socket);
    return 0;
}
