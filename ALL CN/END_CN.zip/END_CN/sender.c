#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/ip.h>
#include <netinet/in.h>
#include <arpa/inet.h>

void print_ipheader(struct iphdr* ip)
{
    printf("------------------------\n");
    printf("Printing IP header....\n");
    printf("IP version:%u\n", (unsigned int)ip->version);
    printf("IP header length:%u\n", (unsigned int)ip->ihl);
    printf("Type of service:%u\n", (unsigned int)ip->tos);
    printf("Total ip packet length:%u\n", ntohs(ip->tot_len));
    printf("Packet id:%u\n", ntohs(ip->id));
    printf("Time to leave :%u\n", (unsigned int)ip->ttl);
    printf("Protocol:%u\n", (unsigned int)ip->protocol);
    printf("Check:%u\n", ip->check);
    printf("Source ip:%s\n", inet_ntoa(*(struct in_addr*)&ip->saddr));
    printf("Destination ip:%s\n", inet_ntoa(*(struct in_addr*)&ip->daddr));
    printf("End of IP header\n");
    printf("------------------------\n");
}

int main() {
    int rsfd = socket(AF_INET, SOCK_RAW, 100);
    if (rsfd < 0) {
        printf("Error in creating socket\n");
        exit(0);
    }
    while (1) {
        char buffer[4096];
        struct sockaddr_in client;
        int len = sizeof(client);
        int n = recvfrom(rsfd, buffer, 4096, 0, (struct sockaddr*)&client, (socklen_t*)&len);
        if (n < 0) {
            printf("Error in receiving packet\n");
            exit(0);
        }
        struct iphdr* ip = (struct iphdr*)buffer;
        for (int i = ip->ihl * 4; i < n; i++) {
            printf("%c", buffer[i]);
        }
        printf("\n");
    }

    return 0;
}
