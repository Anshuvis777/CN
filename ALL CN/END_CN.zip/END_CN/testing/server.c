#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <errno.h>

#define PORT1 8080
#define PORT2 8081
#define PORT3 8082

#define MAX_CLIENTS1 3
#define MAX_CLIENTS2 5
#define MAX_CLIENTS3 7

#define BUFFER_SIZE 1024

void send_connection_failed(int socket) {
    char *message = "Connection failed due to maximum limit\n";
    send(socket, message, strlen(message), 0);
    close(socket);
}

int main() {
    int server_fd1, server_fd2, server_fd3, new_socket, activity;
    int max_sd, sd, i, valread;
    int client_socket1[MAX_CLIENTS1], client_socket2[MAX_CLIENTS2], client_socket3[MAX_CLIENTS3];
    int opt = 1;
    int addrlen;
    struct sockaddr_in address;
    fd_set readfds;
    char buffer[BUFFER_SIZE];

    // Initialize all client_socket arrays to 0 (no clients)
    for (i = 0; i < MAX_CLIENTS1; i++) client_socket1[i] = 0;
    for (i = 0; i < MAX_CLIENTS2; i++) client_socket2[i] = 0;
    for (i = 0; i < MAX_CLIENTS3; i++) client_socket3[i] = 0;

    // Create sockets for each service
    if ((server_fd1 = socket(AF_INET, SOCK_STREAM, 0)) == 0 ||
        (server_fd2 = socket(AF_INET, SOCK_STREAM, 0)) == 0 ||
        (server_fd3 = socket(AF_INET, SOCK_STREAM, 0)) == 0) {
        perror("socket failed");
        exit(EXIT_FAILURE);
    }

    // Set socket options
    if (setsockopt(server_fd1, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) ||
        setsockopt(server_fd2, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) ||
        setsockopt(server_fd3, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt))) {
        perror("setsockopt");
        exit(EXIT_FAILURE);
    }

    // Define address structure
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;

    // Bind each server socket to its respective port
    address.sin_port = htons(PORT1);
    if (bind(server_fd1, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("bind failed");
        exit(EXIT_FAILURE);
    }
    address.sin_port = htons(PORT2);
    if (bind(server_fd2, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("bind failed");
        exit(EXIT_FAILURE);
    }
    address.sin_port = htons(PORT3);
    if (bind(server_fd3, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("bind failed");
        exit(EXIT_FAILURE);
    }

    // Listen for incoming connections
    if (listen(server_fd1, MAX_CLIENTS1) < 0 ||
        listen(server_fd2, MAX_CLIENTS2) < 0 ||
        listen(server_fd3, MAX_CLIENTS3) < 0) {
        perror("listen");
        exit(EXIT_FAILURE);
    }

    addrlen = sizeof(address);
    printf("Waiting for connections...\n");

    while (1) {
        // Clear the socket set
        FD_ZERO(&readfds);

        // Add server sockets to set
        FD_SET(server_fd1, &readfds);
        FD_SET(server_fd2, &readfds);
        FD_SET(server_fd3, &readfds);
        max_sd = server_fd3;

        // Add child sockets to set
        for (i = 0; i < MAX_CLIENTS1; i++) {
            sd = client_socket1[i];
            if (sd > 0) FD_SET(sd, &readfds);
            if (sd > max_sd) max_sd = sd;
        }
        for (i = 0; i < MAX_CLIENTS2; i++) {
            sd = client_socket2[i];
            if (sd > 0) FD_SET(sd, &readfds);
            if (sd > max_sd) max_sd = sd;
        }
        for (i = 0; i < MAX_CLIENTS3; i++) {
            sd = client_socket3[i];
            if (sd > 0) FD_SET(sd, &readfds);
            if (sd > max_sd) max_sd = sd;
        }

        // Wait for an activity on one of the sockets
        activity = select(max_sd + 1, &readfds, NULL, NULL, NULL);

        if ((activity < 0) && (errno != EINTR)) {
            perror("select error");
        }

        // Check for new connections on each server socket
        if (FD_ISSET(server_fd1, &readfds)) {
            if ((new_socket = accept(server_fd1, (struct sockaddr *)&address, (socklen_t *)&addrlen)) < 0) {
                perror("accept");
                exit(EXIT_FAILURE);
            }
            printf("New connection on port %d, socket fd: %d\n", PORT1, new_socket);
            for (i = 0; i < MAX_CLIENTS1; i++) {
                if (client_socket1[i] == 0) {
                    client_socket1[i] = new_socket;
                    break;
                }
            }
            if (i == MAX_CLIENTS1) {
                send_connection_failed(new_socket);
            }
        }
        if (FD_ISSET(server_fd2, &readfds)) {
            if ((new_socket = accept(server_fd2, (struct sockaddr *)&address, (socklen_t *)&addrlen)) < 0) {
                perror("accept");
                exit(EXIT_FAILURE);
            }
            printf("New connection on port %d, socket fd: %d\n", PORT2, new_socket);
            for (i = 0; i < MAX_CLIENTS2; i++) {
                if (client_socket2[i] == 0) {
                    client_socket2[i] = new_socket;
                    break;
                }
            }
            if (i == MAX_CLIENTS2) {
                send_connection_failed(new_socket);
            }
        }
        if (FD_ISSET(server_fd3, &readfds)) {
            if ((new_socket = accept(server_fd3, (struct sockaddr *)&address, (socklen_t *)&addrlen)) < 0) {
                perror("accept");
                exit(EXIT_FAILURE);
            }
            printf("New connection on port %d, socket fd: %d\n", PORT3, new_socket);
            for (i = 0; i < MAX_CLIENTS3; i++) {
                if (client_socket3[i] == 0) {
                    client_socket3[i] = new_socket;
                    break;
                }
            }
            if (i == MAX_CLIENTS3) {
                send_connection_failed(new_socket);
            }
        }

        // Check each client socket for incoming data
        for (i = 0; i < MAX_CLIENTS1; i++) {
            sd = client_socket1[i];
            if (FD_ISSET(sd, &readfds)) {
                if ((valread = read(sd, buffer, BUFFER_SIZE)) == 0) {
                    // Client disconnected, close the socket and mark as 0 in list
                    getpeername(sd, (struct sockaddr*)&address, (socklen_t*)&addrlen);
                    printf("Client disconnected, ip %s, port %d\n", inet_ntoa(address.sin_addr), ntohs(address.sin_port));
                    close(sd);
                    client_socket1[i] = 0;
                } else {
                    // Print the received data
                    buffer[valread] = '\0';
                    printf("Received from client on port %d: %s\n", PORT1, buffer);
                }
            }
        }
        for (i = 0; i < MAX_CLIENTS2; i++) {
            sd = client_socket2[i];
            if (FD_ISSET(sd, &readfds)) {
                if ((valread = read(sd, buffer, BUFFER_SIZE)) == 0) {
                    // Client disconnected, close the socket and mark as 0 in list
                    getpeername(sd, (struct sockaddr*)&address, (socklen_t*)&addrlen);
                    printf("Client disconnected, ip %s, port %d\n", inet_ntoa(address.sin_addr), ntohs(address.sin_port));
                    close(sd);
                    client_socket2[i] = 0;
                } else {
                    // Print the received data
                    buffer[valread] = '\0';
                    printf("Received from client on port %d: %s\n", PORT2, buffer);
                }
            }
        }
        for (i = 0; i < MAX_CLIENTS3; i++) {
            sd = client_socket3[i];
            if (FD_ISSET(sd, &readfds)) {
                if ((valread = read(sd, buffer, BUFFER_SIZE)) == 0) {
                    // Client disconnected, close the socket and mark as 0 in list
                    getpeername(sd, (struct sockaddr*)&address, (socklen_t*)&addrlen);
                    printf("Client disconnected, ip %s, port %d\n", inet_ntoa(address.sin_addr), ntohs(address.sin_port));
                    close(sd);
                    client_socket3[i] = 0;
                } else {
                    // Print the received data
                    buffer[valread] = '\0';
                    printf("Received from client on port %d: %s\n", PORT3, buffer);
                }
            }
        }
    }

    return 0;
}
