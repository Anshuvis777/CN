#include <stdio.h>
#include <stdlib.h>
#include <ucontext.h>

#define STACK_SIZE 16384

ucontext_t contextA, contextB, contextC, contextD;

int countA = 1, countB = 1, countC = 1, countD = 1;

void mydelay() {
    int i;
    for (i = 0; i < 0x00ffffff; i++);
}

void RoutineA() {
    while (1) {
        printf("Coroutine A: %d\n", countA++);
        mydelay();
        swapcontext(&contextA, &contextB);
    }
}

void RoutineB() {
    while (1) {
        printf("Coroutine B: %d\n", countB++);
        mydelay();
        swapcontext(&contextB, &contextC);
    }
}

void RoutineC() {
    while (1) {
        printf("Coroutine C: %d\n", countC++);
        mydelay();
        swapcontext(&contextC, &contextD);
    }
}

void RoutineD() {
    while (1) {
        printf("Coroutine D: %d\n", countD++);
        mydelay();
        swapcontext(&contextD, &contextA);
    }
}

int main() {
    // Initialize contexts
    getcontext(&contextA);
    contextA.uc_stack.ss_sp = malloc(STACK_SIZE);
    contextA.uc_stack.ss_size = STACK_SIZE;
    makecontext(&contextA, RoutineA, 0);

    getcontext(&contextB);
    contextB.uc_stack.ss_sp = malloc(STACK_SIZE);
    contextB.uc_stack.ss_size = STACK_SIZE;
    makecontext(&contextB, RoutineB, 0);
    
    getcontext(&contextC);
    contextC.uc_stack.ss_sp = malloc(STACK_SIZE);
    contextC.uc_stack.ss_size = STACK_SIZE;
    makecontext(&contextC, RoutineC, 0);

    getcontext(&contextD);
    contextD.uc_stack.ss_sp = malloc(STACK_SIZE);
    contextD.uc_stack.ss_size = STACK_SIZE;
    makecontext(&contextD, RoutineD, 0);

    // Start with RoutineA
    swapcontext(&contextD, &contextA);

    // Cleanup (this part is never reached in this example)
    free(contextA.uc_stack.ss_sp);
    free(contextB.uc_stack.ss_sp);
    free(contextC.uc_stack.ss_sp);
    free(contextD.uc_stack.ss_sp);

    return 0;
}