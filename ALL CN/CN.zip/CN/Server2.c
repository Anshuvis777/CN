#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netinet/ip.h>

//sending an IP packet.
int main(){
	//raw socket creation.
	int rsfd=socket(AF_INET,SOCK_RAW,254);
	if(rsfd < 0){
		perror("Error during raw socket creation");
		exit(0);
	}
	
	int value=1;
	setsockopt(rsfd,IPPROTO_IP,IP_HDRINCL,&value,sizeof(value));

	
	//prepare the IP Packet.
	char packet[4096];
	struct iphdr* ip;
	ip=(struct iphdr*)packet;
	
	
	char data[]="Hey Sid!";
	
	//filling IP header fields.
	ip->version=4;
	ip->ihl=5;//1. 
	ip->tos=0;
	ip->tot_len = htons(ip->ihl*4 + strlen(data)); // Total length
	ip->id=htons(12345);
	ip->frag_off=0;
	ip->ttl=64;
	ip->protocol=254;
	ip->check=0;
	ip->saddr=inet_addr("127.0.0.4");
	ip->daddr=inet_addr("127.0.0.1");
	
	memcpy(packet+sizeof(struct iphdr),data,strlen(data));
	
	//sending the packet:
	struct sockaddr_in DA;
	DA.sin_family=AF_INET;
	DA.sin_addr.s_addr=ip->daddr;
	//printf("%d",ntohs(ip->tot_len));
	int ret=sendto(rsfd,packet,ntohs(ip->tot_len),0,(struct sockaddr*)&DA,sizeof(DA));//3.
	printf("%d\n",ret);
	close(rsfd);
	return 0;
}

/*
packet: used to sotre raw packet.
ip: ip is a pointer that points to structure of type iphdr.
ip=(struct iphdr*)packet --> This line assigns the memory address of the packet array to the pointer ip, after type-casting it to be of type struct iphdr* so that the packet array can be used to store an IP header at its beginning. By doing this, you can manipulate the fields of the IP header directly through the ip pointer.
*/

/*
version: IPv4/IPv6
ihl: IP header length --> generally expressed in number of words (4 bytes).
tos:TOS stands for "Type of Service". This field is used to prioritize different types of IP traffic. It can indicate preferences for delay, throughput, reliability, and cost. However, in practice, the Differentiated Services (DiffServ) field in the IP header is more commonly used for this purpose.
tot_len:"Total Length" field specifies the total length of the IP packet, including both the header and the data, measured in bytes.
id: "Identification" is a unique value assigned to a fragment of an IP packet. It is used to reassemble fragmented IP packets at the destination.
frag_off:"Fragment Offset" is used when a packet is fragmented during transmission. It indicates the position of the fragment's data in the original unfragmented packet.
ttl:"Time to Live" represents the maximum number of hops a packet can take before it is discarded. It is used to prevent packets from endlessly circulating in a network.
protocol: This field identifies the protocol that is encapsulated in the payload of the IP packet. For example, it might indicate that the payload contains TCP, UDP, ICMP, or other protocols.
check: "Header Checksum" is used to verify the integrity of the IP header during transmission. It helps detect errors in the header caused by transmission issues.
saddr: "Source Address" represents the IP address of the sender of the packet.
daddr: "Destination Address" represents the IP address of the intended recipient of the packet.

These fields collectively form the IP header, which is a crucial part of the IP packet and contains essential information for routing and handling the packet across a network.
*/
