// p1.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netinet/ip.h>
#include <sys/socket.h>
#include <pthread.h>

#define PORT 8080
#define MAX_MSG_SIZE 1024

void error(const char *msg) {
    perror(msg);
    exit(EXIT_FAILURE);
}

void *receiveBroadcast(void *arg) {
    int sockfd;
    struct sockaddr_in server_addr;

    // Create raw socket
    if ((sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_UDP)) == -1) {
        error("Socket creation failed for receiving broadcast");
    }

    // Enable broadcast
    int broadcastEnable = 1;
    if (setsockopt(sockfd, SOL_SOCKET, SO_BROADCAST, &broadcastEnable, sizeof(broadcastEnable)) == -1) {
        error("Setting broadcast option failed for receiving broadcast");
    }

    memset(&server_addr, 0, sizeof(server_addr));

    // Server address configuration
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = htonl(INADDR_ANY); // Use htonl(INADDR_ANY) to bind to all available interfaces
    server_addr.sin_port = htons(PORT);

    // Bind the socket
    if (bind(sockfd, (const struct sockaddr *)&server_addr, sizeof(server_addr)) == -1) {
        error("Bind failed");
    }

    printf("p1 listening for broadcast messages...\n");

    char buffer[MAX_MSG_SIZE];

    while (1) {
        // Receive broadcast message
        if (recvfrom(sockfd, (char *)buffer, sizeof(buffer), 0, NULL, NULL) == -1) {
            error("Receive failed");
        }

        printf("p1 received broadcast message: %s", buffer);
    }

    close(sockfd);

    return NULL;
}

int main() {
    pthread_t receive_thread;

    if (pthread_create(&receive_thread, NULL, receiveBroadcast, NULL) != 0) {
        fprintf(stderr, "Error creating receive thread for p1\n");
        exit(EXIT_FAILURE);
    }

    // p1 can do other things...

    pthread_join(receive_thread, NULL);

    return 0;
}
