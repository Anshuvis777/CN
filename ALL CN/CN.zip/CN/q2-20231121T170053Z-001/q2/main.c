// main.c
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <netinet/ip.h>
#include <sys/socket.h>
#include <pthread.h>

#define PORT 8080
#define MAX_MSG_SIZE 1024

void error(const char *msg) {
    perror(msg);
    exit(EXIT_FAILURE);
}

void *sendBroadcast(void *arg) { 
    int sockfd;
    struct sockaddr_in broadcast_addr;

    // Create raw socket
    if ((sockfd = socket(AF_INET, SOCK_RAW, IPPROTO_UDP)) == -1) {
        error("Socket creation failed for sending broadcast");
    }

    // Enable broadcast
    int broadcastEnable = 1;
    if (setsockopt(sockfd, SOL_SOCKET, SO_BROADCAST, &broadcastEnable, sizeof(broadcastEnable)) == -1) {
        error("Setting broadcast option failed for sending broadcast");
    }

    memset(&broadcast_addr, 0, sizeof(broadcast_addr));

    // Broadcast address configuration (replace with the actual broadcast address of your subnet)
    broadcast_addr.sin_family = AF_INET;
    broadcast_addr.sin_addr.s_addr = inet_addr("127.0.0.1");  // Example: Replace with your broadcast address
    broadcast_addr.sin_port = htons(PORT);

    char buffer[MAX_MSG_SIZE];

    while (1) {
        // Get user input
        printf("Enter broadcast message: ");
        fgets(buffer, MAX_MSG_SIZE, stdin);

        // Send datagram packet
        if (sendto(sockfd, (const char *)buffer, strlen(buffer), 0, (const struct sockaddr *)&broadcast_addr, sizeof(broadcast_addr)) == -1) {
            error("Broadcast failed");
        }
    }

    close(sockfd);

    return NULL;
}

int main() {
    pthread_t broadcast_thread;

    if (pthread_create(&broadcast_thread, NULL, sendBroadcast, NULL) != 0) {
        fprintf(stderr, "Error creating broadcast thread\n");
        exit(EXIT_FAILURE);
    }

    // Main program can do other things...
    pthread_join(broadcast_thread, NULL);

    return 0;
}
