#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/ip.h>
#include <arpa/inet.h>

int main(){
	//raw socket creation.
	int rsfd=socket(AF_INET,SOCK_RAW,254);
	if(rsfd < 0){
		perror("Raw Socket creation");
		exit(0);
	}
	
	char packet[4096];
	struct sockaddr_in SA;
	int SAlen=sizeof(SA);
	int packet_size=recvfrom(rsfd,packet,sizeof(packet),0,(struct sockaddr*)&SA,&SAlen);//4.
	if(packet_size < 0){
		perror("Error during recvfrom system call");
		exit(0);
	}
	
	struct iphdr* ip=(struct iphdr*)packet;
	printf("Source address : %d\n",ip->saddr);
	printf("Destination address: %d\n",ip->daddr);
	
	char* payload=packet+(ip->ihl)*4;//5.
	int payload_size=ntohs(ip->tot_len)-(ip->ihl)*4;//6.
	
	printf("IP Header Length: %d\n",ip->ihl);
	printf("Total length of IP: %d\n",ntohs(ip->tot_len));
	printf("Payload size: %d\n",payload_size);
	printf("Payload: %s\n",payload);
	
}
