#include<stdio.h>
int main(){
    
    int i = 0;
    int c = fork();
}